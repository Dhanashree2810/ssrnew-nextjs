import { LoginForm } from "./ui/login";


export default function Home() {

  return (
    <>
      <h1>1st Time Buyer? Use "FIRST" Promo Code To Instantly Get 10% OFF!</h1>
    </>
  );
}