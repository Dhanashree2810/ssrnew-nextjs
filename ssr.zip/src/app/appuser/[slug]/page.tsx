import AppUserMainForm from "@/app/pages/appuser/AppUserMainForm";

const AddAppUserPage = () => {
    return < AppUserMainForm />;
};

export default AddAppUserPage;
